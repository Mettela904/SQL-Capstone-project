-- (1) What is the distribution of account balances across different regions?

select GeographyLocation as Region,round(sum(Balance),2) as Balance from bank_details b join customerinfo c on b.CustomerId=c.CustomerId
join location l on c.GeographyID=l.GeographyID group by 1;

-- (2) Identify the top 5 customers with the highest Estimated Salary in the last quarter of the year. (SQL)

select CustomerId,EstimatedSalary from customerinfo where month(BankDOJ) in (10,11,12) order by EstimatedSalary desc limit 5;

-- (3) Calculate the average number of products used by customers who have a credit card. (SQL)

select avg(NumOfProducts) as `average number of products ` from bank_details where HasCrCard=1;

-- (4) Determine the churn rate by gender for the most recent year in the dataset.                                    

select g.GenderCategory as Gender, 
       round(count(case when exited= 1 then b.CustomerId end)*100/ count(b.CustomerId),2)
        as churn_rate
        from bank_details b join customerinfo c on b.CustomerId= c.CustomerId
        join gender g ON g.GenderID= c.GenderID
        where year(bankDOJ)=2019
        group by GenderCategory;
-- (5) Compare the average credit score of customers who have exited and those who remain. (SQL)

select case when Exited=1 then 'Exited' else 'Remain' end `Customer Status`
,avg(CreditScore) as `average credit score of customers` from bank_details group by Exited;

-- (6) Which gender has a higher average estimated salary and how does it relate to the number of active accounts? (SQL)

select g.GenderCategory,round(avg(c.EstimatedSalary),2) as ` average estimated salary`,count(b.IsActiveMember) as `number of active accounts`

from bank_details b join customerinfo c on b.CustomerId=c.CustomerId join gender g on c.GenderID=g.GenderID 

where b.IsActiveMember=1 group by 1;

-- (7) Segment the customers based on their credit score and identify the segment with the highest exit rate. (SQL)


select case when CreditScore>=800 then '>800' when CreditScore<800 and CreditScore>=740 then '740-799' 
		    when CreditScore<740 and CreditScore>=670 then '670-739' when CreditScore<670 and CreditScore>=580 then '580-669'
            else '<580' end `Credit score range`,
            case when CreditScore>=800 then 'Excellent' when CreditScore<800 and CreditScore>=740 then 'Very_Good' 
		    when CreditScore<740 and CreditScore>=670 then 'Good' when CreditScore<670 and CreditScore>=580 then 'Fair'
            else 'Poor' end `Credit score segment`,count(CustomerId) as `Number of customers exited`
            from bank_details where Exited=1 group by 1,2;
            
-- (8) Find out which geographic region has the highest number of active customers with a tenure greater than 5 years. (SQL)

select l.GeographyLocation as Region,count(b.CustomerId) as `Number of active customers` 

from bank_details b join customerinfo c on b.CustomerId=c.CustomerId join  location l on c.GeographyID=l.GeographyID 

where b.IsActiveMember =1 and Tenure>5 group by 1 ;

-- (9) What is the impact of having a credit card on customer churn, based on the available data?

select c.category,count(b.customerid) as `Number of Customers`,
	   sum(case when b.Exited=1 then 1 else 0 end) as `Number of Exited Customers`,
       round(sum(case when b.Exited=1 then 1 else 0 end)*100/count(b.CustomerId),2) as `Churn Rate`
	   from bank_details b join creditcard c on b.HasCrCard=c.CreditID group by 1;
       
-- (10) For customers who have exited, what is the most common number of products they have used?

select Numofproducts as `Number of products`,
       sum(case when exited=1 then 1 else 0 end) as `Number of customers used` 
       from bank_details group by 1;
-- (11) Examine the trend of customers joining over time and identify any seasonal patterns (yearly or monthly).
--       Prepare the data through SQL and then visualize it

select year(bankdoj) as year,
        case when month(BankDOJ)>=1 and month(BankDOJ)<=3 then 'Q1' when  month(BankDOJ)>=4 and month(BankDOJ)<=6 then 'Q2'
       when month(BankDOJ)>=7 and month(BankDOJ)<=9 then 'Q3' else 'Q4' end as season,
        count(customerid) as `Number of Customers` from customerinfo group by 1,2 order by 1,2;
        
-- (12) Analyze the relationship between the number of products and the account balance for customers who have exited.

    select Numofproducts as `product id`,round(avg(balance),2) as `Average Balance`,
     count(customerid) as `Number of Customers` from bank_details where Exited=1 group by 1 order by 1;
     
-- (13) Identify any potential outliers in terms of spend among customers who have remained with the bank.

select Exitcategory,round(EstimatedSalary-balance,2) as Spending from bank_details b join customerinfo c on b.CustomerId=c.CustomerId
       join exitcustomer e on b.Exited=e.ExitID where b.Exited=0;


-- (15) Using SQL, write a query to find out the gender-wise average income of males and females in each geography id. 
--      Also, rank the gender according to the average value. (SQL)

     select Gendercategory as Gender,Geographylocation as Region,round(avg(EstimatedSalary),2) as `Average Income`,
            rank() over(order by avg(EstimatedSalary) desc) as Ranking
			from customerinfo c join gender g on c.GenderID=g.GenderID join location l on c.GeographyID=l.GeographyID
			group by 1,2 ;

-- (16)  Using SQL, write a query to find out the average tenure of the people who have exited in each age bracket (18-30, 30-50, 50+).


          select case when age>=18 and age<=30 then '18-30' when age>30 and age<50 then '30-50' else '50+' end as `Age Bracket`,
          round(avg(Tenure),2) as `Average Tenure` 
		  from customerinfo c join bank_details b on c.CustomerId=b.CustomerId Where Exited=1
		  group by 1 order by 1;
-- (17) Is there any direct correlation between the salary and the balance of the customers?
--      And is it different for people who have exited or not?

 select exitcategory,round(avg(Balance),2) as `Average Balance`,round(avg(estimatedsalary),2) 
as `Average Salary` from bank_details b join customerinfo c on b.CustomerId=c.customerid 
join exitcustomer e on b.Exited=e.ExitID
group by 1;

-- (18) Is there any correlation between the salary and the Credit score of customers?

select case when CreditScore>=800 then '>800' when CreditScore<800 and CreditScore>=740 then '740-799' 
		    when CreditScore<740 and CreditScore>=670 then '670-739' when CreditScore<670 and CreditScore>=580 then '580-669'
            else '<580' end `Credit score range`,
            case when CreditScore>=800 then 'Excellent' when CreditScore<800 and CreditScore>=740 then 'Very_Good' 
		    when CreditScore<740 and CreditScore>=670 then 'Good' when CreditScore<670 and CreditScore>=580 then 'Fair'
            else 'Poor' end `Credit score segment`,round(avg(estimatedsalary),2) as `Average salary` 
            from bank_details b join customerinfo c on b.CustomerId=c.CustomerId
            group by 1,2;



-- (19) Rank each bucket of credit score as per the number of customers who have churned the bank.

select case when CreditScore>=800 then '>800' when CreditScore<800 and CreditScore>=740 then '740-799' 
		    when CreditScore<740 and CreditScore>=670 then '670-739' when CreditScore<670 and CreditScore>=580 then '580-669'
            else '<580' end `Credit score range`,
            count(customerid) as `Number of Customers` ,
            rank() over(order by count(CustomerId) desc) as ranking
            from bank_details where Exited=1 group by 1;
            
-- (20) According to the age buckets find the number of customers who have a credit card.
--      Also, retrieve those buckets that have a lesser than average number of credit cards per bucket.

with temp as (
	select case when age>=18 and age<=30 then '18-30' when age>30 and age<50 then '30-50' else '50+' end as Age_Bucket,
           count(c.customerid) as n
           from customerinfo c join bank_details b on c.CustomerId=b.CustomerId
           where hascrcard=1 group by 1)
           
           select age_bucket as `Age Bucket`,n as `Number of Customers` from temp 
           where n>(select avg(n) from temp);
           
-- (21)  Rank the Locations as per the number of people who have churned the bank and the average balance of the learners.

    select GeographyLocation,count(c.customerid) as `Number of Customers`,round(avg(balance),2) as `Average Balance`,
           rank() over(order by count(c.customerid) desc) as Ranking 
           from customerinfo c join bank_details b on c.CustomerId=b.CustomerId join location l on c.GeographyID=l.GeographyID
		   where exited=1 group by 1;









